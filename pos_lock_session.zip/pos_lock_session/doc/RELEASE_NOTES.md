## Module <pos_lock_session>

#### 13.02.2019
#### Version 12.0.1.0.0
#### Module Migrated
