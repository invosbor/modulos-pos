Product Reference in POS v12
======================================

    This module enables user to print the product Reference in  in POS receipts

Installation
============
    - www.odoo.com/documentation/12.0/setup/install.html
    - Install our custom addon

Credits
=======
    Developer: IJAZ AHAMMED E @ cybrosys, Contact: odoo@cybrosys.com
