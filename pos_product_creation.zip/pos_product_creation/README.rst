========================
Pos Product Creation v12
========================

This module adds product creation button an wizard in pos.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Credits
=======
Developer V10: Linto CT @ cybrosys, odoo@cybrosys.com
          V12: Akshay Babu @ cybrosys,

