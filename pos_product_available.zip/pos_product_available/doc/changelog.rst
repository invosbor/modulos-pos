.. _changelog:

Updates
=======

`1.0.6`
-------

- **FIX:** Added compatibility with pos_multi_session

`1.0.5`
-------

- **FIX:** Product quantities representation according to the set location
- **FIX:** Product quantities representation only for stockable products

`1.0.4`
-------

- [FIX] incorrect products quantity numbers with pos_cache module.

`1.0.3`
-------

- [FIX] compatibility with pos_cache module. Thanks to MindAndGo.

`1.0.2`
-------

- [FIX] update product counter when sale via invoice

`1.0.1`
-------

- Show quantity related to POS's stock location only.
