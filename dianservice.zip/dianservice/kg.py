import string
import random
import socket

print(socket.gethostname())

def id_generator(size=20, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

index = 0
#with open('keys.txt','w') as file:
#    while index < 1000:
#        key_licence = id_generator()
#        file.write(key_licence + '\n')
r = []
file = open("keys.txt", "r")
for key in file:
    r.append(key.strip("\n"))

print (r)