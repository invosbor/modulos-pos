from dianservice.dianservice import Service
import os
from zipfile import ZipFile
import base64, random
from lxml import etree

xmlPath = "/odooCOLOMBIA19/custom/addons/dian_efact/models/xml"

DianService = Service()

DianService.setXMLPath(xmlPath)
DianService.fileXmlName = "face_f11127681430000000018" #face_d, face_c for notes over invoices
DianService.fileZipName = "ws_f11127681430000000018" # output ws_fnnnnnnnnnnhhhhhhhhhh.zip  ws_d, ws_c for notes
DianService.initDianAPI("SANDBOX", "sendBill")

response = DianService.consultNIT(str("1112768143"))
print(response)

data = {
            "serie":"face_f",
            "numero":"0000000011",
            "emisor":{
                        "tipo_documento":"31",
                        "nro":"1112768143",
                        "nombre":"ROCKSCRIPTS",
                        "regimen":"0",
                        "direccion":"Cra 14 18N118",
                        "ciudad":"Armenia",
                        "ciudad_sector":"sector A",
                        "departamento":"Quindio",
                        "codigoPostal":"63001",
                        "codigoPais":"CO"
                     },
            "receptor":{
                            "tipo_documento":"13",
                            "nro":"24642786",
                            "nombre":"Ana Agudelo",
                            "regimen":"0",
                            "direccion":"carrera 8 N\u00ba 6C - 46",
                            "ciudad":"Toribio",
                            "ciudad_sector":"sector B",
                            "departamento":"Valle del Cauca",
                            "codigoPostal":"150204",
                            "codigoPais":"CO"
                        },
            "fechaEmision":"2019-04-29",
            "fechaVencimiento":"2019-04-29",
            "horaEmision":"17:00:11",
            "totalVenta":151000.0,
            "totalVentaGravada":185215.0,
            "tipoMoneda":"COP",
            "items":[
                        {
                        "id":"23",
                        "cantidad":"1.0",
                        "descripcion":"[U08] SmartWatch",
                        "subTotalVenta":16000.0,
                        "totalVenta":19840.0,
                        "tributos":[
                                        {
                                            "codigo":"01",
                                            "porcentaje":19.0,
                                            "montoAfectacionTributo":3040.0,
                                            "total_venta":16000.0
                                        },
                                        {
                                            "codigo":"01",
                                            "porcentaje":5.0,
                                            "montoAfectacionTributo":800.0,
                                            "total_venta":16000.0
                                        }
                                    ]
                        },
                        {
                        "id":"24",
                        "cantidad":"1.0",
                        "descripcion":"Subwoofer Pioner TS-W306R",
                        "subTotalVenta":135000.0,
                        "totalVenta":165375.0,
                        "tributos":[
                                        {
                                            "codigo":"01",
                                            "porcentaje":19.0,
                                            "montoAfectacionTributo":25650.0,
                                            "total_venta":135000.0
                                        },
                                        {
                                            "codigo":"02",
                                            "porcentaje":3.5,
                                            "montoAfectacionTributo":4725.0,
                                            "total_venta":135000.0
                                        }
                                    ]
                        }
                    ],
            "tributos":{
                        "01":[
                                {
                                    "codigo":"01",
                                    "total_venta":151000.0,
                                    "porcentaje":19.0,
                                    "sumatoria":28690.0
                                },
                                {
                                    "codigo":"01",
                                    "total_venta":16000.0,
                                    "porcentaje":5.0,
                                    "sumatoria":800.0
                                }
                             ],
                        "02":[
                                {
                                    "codigo":"02",
                                    "total_venta":135000.0,
                                    "porcentaje":3.5,
                                    "sumatoria":4725.0
                                }
                             ]
            },
            "dian":{
                        "nit":"900373115",
                        "usuario":"0d2e2883-eb8d-4237-87fe-28aeb71e961e",
                        "clave":"bdaa51c9953e08dcc8f398961f7cd0717cd5fbea356e937660aa1a8abbe31f4c9b4eb5cf8682eaca4c8523953253dcce",
                        "nonce":"MC4xNDU3MzY3ODAxNTcyNTAzMw==",
                        "created":"2019-04-15T22:23:35",
                        "autorizacion":{
                                            "codigo":"9000000500017960",
                                            "codigo_pais":"CO",
                                            "fecha_inicio":"2016-07-11",
                                            "fecha_fin":"2018-07-11",
                                            "prefijo":"PRUE",
                                            "desde":"980000000",
                                            "hasta":"985000000"
                                        }
                    },
            "licencia":"081OHTGAVHJZ4GOZJGJV"
            }


#data ={
#        "secuencia_consecutivo":"0000000018",
#        "dian":{
#                    "nit":"1112768143",
#                    "usuario":"20603408111MODDATOS",
#                    "clave":"moddatos",
#                    "nonce":"MC4wOTc3MDg0MTI0MDM5ODczMQ==",
#                    "created":"2019-04-15T22:23:35"
#                },
#        "xml":{
#              },
#        "licencia":"081OHTGAVHJZ4GOZJGJV"
#       }
#response = DianService.processInvoice(data)
#print (response)


#response = DianService.processTicket([])
#response = DianService.processNota("debit",[])
#response = DianService.processNota("credit",[])
#response = DianService.searchMerchant("RUC_NUMBER")




#<SOAP-ENV:Envelope
#	xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">
#	<SOAP-ENV:Header/>
#	<SOAP-ENV:Body>
#		<SOAP-ENV:Fault>
#			<faultcode>SOAP-ENV:Server</faultcode>
#			<faultstring xml:lang=\"en\">org.springframework.security.core.userdetails.UsernameNotFoundException: Error al auntenticar username/password [0d2e2883-eb8d-4237-87fe-28aeb71e961e]</faultstring>
#		</SOAP-ENV:Fault>
#	</SOAP-ENV:Body>
#</SOAP-ENV:Envelope>





#rp = os.path.dirname(__file__) # relative directory path
#ap = os.path.abspath(__file__) # absolute file path
#fn = os.path.basename(__file__) # the file name only
#print(rp)
#print(ap)
#print(fn)

#print (str(round(float("0.972"),2)))