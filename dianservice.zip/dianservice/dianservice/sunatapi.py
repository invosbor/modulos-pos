import base64
import requests
from lxml import etree
from zipfile import ZipFile
import sys

class SunatApi:

    apiMode = "SANDBOX"

    endPointType = False #INVOICE , GUIDE

    endPointSandBox    = "https://facturaelectronica.dian.gov.co/habilitacion/B2BIntegrationEngine/FacturaElectronica/facturaElectronica.wsdl"
    endPointProduction = "https://facturaelectronica.dian.gov.co/operacion/B2BIntegrationEngine/FacturaElectronica/facturaElectronica.wsdl" 
    # server_url = {
    #                 'HABILITACION':'https://facturaelectronica.dian.gov.co/habilitacion/B2BIntegrationEngine/FacturaElectronica/facturaElectronica.wsdl',
    #                 'PRODUCCION':'https://facturaelectronica.dian.gov.co/operacion/B2BIntegrationEngine/FacturaElectronica/facturaElectronica.wsdl',
    #                 'HABILITACION_CONSULTA':'https://facturaelectronica.dian.gov.co/habilitacion/B2BIntegrationEngine/FacturaElectronica/consultaDocumentos.wsdl',
    #                 'PRODUCCION_CONSULTA':'https://facturaelectronica.dian.gov.co/operacion/B2BIntegrationEngine/FacturaElectronica/consultaDocumentos.wsdl' 
    #              }
    endPointSandBoxGuide    = "https://e-beta.sunat.gob.pe:443/ol-ti-itemision-guia-gem-beta/billService"
    endPointProductionGuide = "https://e-guiaremision.sunat.gob.pe/ol-ti-itemision-guia-gem/billService" 
    
    call = False

    xmlPath = False
    fileName = False
    
       
    def __init__(self, apiMode, call, xmlPath, fileName):
        self.apiMode = apiMode
        self.call = call
        self.xmlPath = xmlPath
        self.fileName = fileName

    def doResquest(self):
        response = {}
        headers = {'Content-Type': 'text/xml',"Accept":"text/xml"}         
        req = requests.Request('POST',self.getEndPoint(),headers=headers, data=self.getXMLrequest())
        prepared = req.prepare()
        s = requests.Session()
        try:
            responseServer = s.send(prepared)
            response = self.getXMLresponse(responseServer)
        except:
            response["status"] = "FAIL"
            response["code"] = "SUNAT - Servidor Ocupado"
            response["body"] = "Servidor no disponible temporalmente, vuelve a intentar."

        #print(response)
        return response
    
    def getXMLrequest(self):
        tree = False
        if(self.call=="sendBill"):
           tree = etree.parse(self.xmlPath+"/XMLrequests/sendBill.XML")
        XMLFileContents = etree.tostring(tree.getroot())
        return XMLFileContents
    
    def getXMLresponse(self, response):
        niceResponse = {}
        objecResponse = etree.fromstring(response.content)
        
        #return niceResponse
        if(self.call=="sendBill"):
            for child in objecResponse.iter('Response'):
                
                if child.text != "":
                   niceResponse["status"] = "OK"
                   niceResponse["body"] = self.handleSendBillResponse(child.text)
            
            if not niceResponse:
                
                for child in objecResponse.iter('faultcode'):
                    niceResponse["status"] = "FAIL"
                    niceResponse["code"] = child.text

                # for child in objecResponse.iter('message'):
                #     niceResponse["body"] = child.text  

                for child in objecResponse.iter('faultstring'):
                    niceResponse["body"] = child.text

        niceResponse["xml_response"] = base64.b64encode(bytes(str(response.content), 'utf-8'))
        self.saveSenBillResponse(niceResponse["xml_response"])
        return niceResponse
    
    def getEndPoint(self):
        if(self.endPointType=="INVOICE"):
            if(self.apiMode=="PRODUCTION"):
                return self.endPointProduction
            else:
                return self.endPointSandBox

        if(self.endPointType=="GUIDE"):
            if(self.apiMode=="PRODUCTION"):
                return self.endPointProductionGuide
            else:
                return self.endPointSandBoxGuide
    
    def setEndPointType(self,typeEndPoint):
        self.endPointType = typeEndPoint
    
    def saveSenBillResponse(self, xmlResponse):
        xmlTarget = str(self.xmlPath+'/XMLresponses/')+str(self.fileName)+".XML"
        responseXMLFile = open(xmlTarget, 'wb')
        responseXMLFile.write(base64.b64decode(xmlResponse))
        responseXMLFile.close()

    def handleSendBillResponse(self, base64encodedContent): 
        zipTarget = str(self.xmlPath+'/XMLresponses/')+str(self.fileName)+".zip"
        responseZipFile = open(zipTarget, 'wb')
        responseZipFile.write(base64.b64decode(base64encodedContent.encode('ascii')))
        responseZipFile.close()
        
        responseZipFile = ZipFile(zipTarget, 'r')       
        xmlResponse = responseZipFile.open(str("R-")+self.fileName+str(".XML")).read()
        tree = etree.ElementTree(etree.fromstring(xmlResponse))
        ApplicationResponse = tree.getroot()
        niceResponse = {}

        for Description in ApplicationResponse.iter(tag='{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}Comments'):
            niceResponse["comments"] = Description.text

        for ReferenceID in ApplicationResponse.iter(tag='{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}ResponseDateTime'):
            niceResponse["date_submited"] = ReferenceID.ResponseDateTime              

        return niceResponse