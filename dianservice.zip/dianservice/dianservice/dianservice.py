from . documents import Documents
from . sunatapi import SunatApi
from . ruc import Ruc

class Service:
    xmlPath = False
    fileXmlName = False
    fileZipName = False
    sunatAPI = False
    keys = ['081OHTGAVHJZ4GOZJGJV']

    def consultNIT(self, ruc):
        
        rucService = Ruc()
        rucService.setXMLPath(self.xmlPath)        
        response = rucService.consultNIT(str(ruc))
        return response

    def processInvoiceFromSignedXML(self, data):
        dataSB = {}
        docs = Documents()
        docs.documentXmlName = self.fileXmlName
        docs.documentZipName = self.fileZipName
        docs.setXMLPath(self.xmlPath)
        zipFileEncoded = docs.Base64EncodeDocument()
        dataSB['sendBillFile'] = self.xmlPath+str("/XMLrequests/sendBill.XML")
        dataSB['fileName'] = self.fileZipName+str(".zip")
        dataSB['InvoiceNumber'] = str("FAC")+str(data['secuencia_consecutivo'])
        dataSB['Document'] = zipFileEncoded
        dataSB['dian'] = data["dian"]
        docs.fillSendBill(dataSB)
        self.sunatAPI.setEndPointType("INVOICE")
        response = self.sunatAPI.doResquest() 
        # collects xml files contentes with or without errors
        response['xml_unsigned'] = docs.getXMLUnsignedDocument()
        response['xml_signed'] = docs.getXMLSignedDocument()
        return response


    def processInvoice(self, data):  
        has_licence = self.validateLicence(data)
        if(has_licence==True):
            has_licence = True
        else:
            return has_licence

        docs = Documents()
        docs.documentXmlName = self.fileXmlName
        docs.documentZipName = self.fileZipName
        docs.setXMLPath(self.xmlPath)
        docs.fillDocument("invoice", data)    
        docs.signDocument(self.xmlPath+'/XMLcertificates/rsakey.pem', self.xmlPath+'/XMLcertificates/rsacert.pem')          
        wasVerified = docs.verifyDocument(self.xmlPath+'/XMLcertificates/rsakey.pem')          
        if(wasVerified):
            wasZipped = docs.zipDocument(self.xmlPath+'/XMLdocuments/3_signed/',self.xmlPath+'/XMLdocuments/4_compressed/',self.fileZipName)            
            if (wasZipped==True):
                    zipFileEncoded = docs.Base64EncodeDocument()
                    dataSB = {}
                    dataSB['sendBillFile'] = self.xmlPath+str("/XMLrequests/sendBill.XML")
                    dataSB['fileName'] = docs.documentZipName+str(".zip")
                    dataSB['Document'] = zipFileEncoded
                    dataSB['InvoiceNumber'] = str("FAC")+str(data['numero'])
                    dataSB['dian'] = data["dian"]
                    docs.fillSendBill(dataSB)
                    self.sunatAPI.setEndPointType("INVOICE")
                    response = self.sunatAPI.doResquest() 
                    # collects xml files contentes with or without errors
                    response['xml_unsigned'] = docs.getXMLUnsignedDocument()
                    response['xml_signed'] = docs.getXMLSignedDocument()
                    return response
            else:
                return "ERROR_DOCUMENT_NOT_ZIPPED"
        else:
            return "ERROR_DOCUMENT_NOT_VERIFIED"
    
    def processTicket(self, data): 
        has_licence = self.validateLicence(data)
        if(has_licence==True):
            has_licence = True
        else:
            return has_licence

        docs = Documents()
        docs.documentXmlName = self.fileXmlName
        docs.setXMLPath(self.xmlPath)
        docs.fillDocument("ticket", data)    
        docs.signDocument(self.xmlPath+'/XMLcertificates/rsakey.pem', self.xmlPath+'/XMLcertificates/rsacert.pem')          
        wasVerified = docs.verifyDocument(self.xmlPath+'/XMLcertificates/rsakey.pem')          
        if(wasVerified):
            wasZipped = docs.zipDocument(self.xmlPath+'/XMLdocuments/3_signed/',self.xmlPath+'/XMLdocuments/4_compressed/',self.fileZipName)            
            if (wasZipped==True):
                    zipFileEncoded = docs.Base64EncodeDocument()
                    dataSB = {}
                    dataSB['sendBillFile'] = self.xmlPath+str("/XMLrequests/sendBill.XML")
                    dataSB['fileName'] = docs.documentXmlName+str(".zip")
                    dataSB['contentFile'] = zipFileEncoded
                    dataSB['sol'] = data["sol"]
                    docs.fillSendBill(dataSB)
                    self.sunatAPI.setEndPointType("INVOICE")
                    response = self.sunatAPI.doResquest()    
                    # collects xml files contentes with or without errors
                    response['xml_unsigned'] = docs.getXMLUnsignedDocument()
                    response['xml_signed'] = docs.getXMLSignedDocument()                
                    return response
            else:
                return "ERROR_DOCUMENT_NOT_ZIPPED"
        else:
            return "ERROR_DOCUMENT_NOT_VERIFIED"

    def processCreditNote(self, data): 
        has_licence = self.validateLicence(data)
        if(has_licence==True):
            has_licence = True
        else:
            return has_licence

        docs = Documents()
        docs.documentXmlName = self.fileXmlName
        docs.documentZipName = self.fileZipName
        docs.setXMLPath(self.xmlPath)
        docs.fillDocument("creditNote", data)    
        docs.signDocument(self.xmlPath+'/XMLcertificates/rsakey.pem', self.xmlPath+'/XMLcertificates/rsacert.pem')          
        wasVerified = docs.verifyDocument(self.xmlPath+'/XMLcertificates/rsakey.pem')          
        if(wasVerified):
            wasZipped = docs.zipDocument(self.xmlPath+'/XMLdocuments/3_signed/',self.xmlPath+'/XMLdocuments/4_compressed/',self.fileZipName)            
            if (wasZipped==True):
                    zipFileEncoded = docs.Base64EncodeDocument()
                    dataSB = {}
                    dataSB['sendBillFile'] = self.xmlPath+str("/XMLrequests/sendBill.XML")
                    dataSB['fileName'] = docs.documentZipName+str(".zip")
                    dataSB['Document'] = zipFileEncoded
                    dataSB['InvoiceNumber'] = str("NCR")+str(data['numero'])
                    dataSB['dian'] = data["dian"]
                    docs.fillSendBill(dataSB)
                    self.sunatAPI.setEndPointType("INVOICE")
                    response = self.sunatAPI.doResquest()  
                    # collects xml files contentes with or without errors
                    response['xml_unsigned'] = docs.getXMLUnsignedDocument()
                    response['xml_signed'] = docs.getXMLSignedDocument()                  
                    return response
            else:
                return "ERROR_DOCUMENT_NOT_ZIPPED"
        else:
            return "ERROR_DOCUMENT_NOT_VERIFIED"


    def processDebitNote(self, data):
        has_licence = self.validateLicence(data)
        if(has_licence==True):
            has_licence = True
        else:
            return has_licence

        docs = Documents()
        docs.documentXmlName = self.fileXmlName
        docs.documentZipName = self.fileZipName
        docs.setXMLPath(self.xmlPath)
        docs.fillDocument("debitNote", data)    
        docs.signDocument(self.xmlPath+'/XMLcertificates/rsakey.pem', self.xmlPath+'/XMLcertificates/rsacert.pem')          
        wasVerified = docs.verifyDocument(self.xmlPath+'/XMLcertificates/rsakey.pem')          
        if(wasVerified):
            wasZipped = docs.zipDocument(self.xmlPath+'/XMLdocuments/3_signed/',self.xmlPath+'/XMLdocuments/4_compressed/',self.fileXmlName)            
            if (wasZipped==True):
                    zipFileEncoded = docs.Base64EncodeDocument()
                    dataSB = {}
                    dataSB['sendBillFile'] = self.xmlPath+str("/XMLrequests/sendBill.XML")
                    dataSB['fileName'] = docs.documentXmlName+str(".zip")
                    dataSB['Document'] = zipFileEncoded
                    dataSB['InvoiceNumber'] = str("NDB")+str(data['numero'])
                    dataSB['dian'] = data["dian"]
                    docs.fillSendBill(dataSB)
                    self.sunatAPI.setEndPointType("INVOICE")
                    response = self.sunatAPI.doResquest()    
                    # collects xml files contentes with or without errors
                    response['xml_unsigned'] = docs.getXMLUnsignedDocument()
                    response['xml_signed'] = docs.getXMLSignedDocument()                  
                    return response
            else:
                return "ERROR_DOCUMENT_NOT_ZIPPED"
        else:
            return "ERROR_DOCUMENT_NOT_VERIFIED"

    def processDeliveryGuide(self, data): 
            has_licence = self.validateLicence(data)
            if(has_licence==True):
                has_licence = True
            else:
                return has_licence

            docs = Documents()
            docs.documentXmlName = self.fileXmlName
            docs.setXMLPath(self.xmlPath)
            docs.fillDocument("deliveryGuide", data)    
            docs.signDocument(self.xmlPath+'/XMLcertificates/rsakey.pem', self.xmlPath+'/XMLcertificates/rsacert.pem')          
            wasVerified = docs.verifyDocument(self.xmlPath+'/XMLcertificates/rsakey.pem')          
            if(wasVerified):
                wasZipped = docs.zipDocument(self.xmlPath+'/XMLdocuments/3_signed/',self.xmlPath+'/XMLdocuments/4_compressed/',self.fileXmlName)            
                if (wasZipped==True):
                        zipFileEncoded = docs.Base64EncodeDocument()
                        dataSB = {}
                        dataSB['sendBillFile'] = self.xmlPath+str("/XMLrequests/sendBill.XML")
                        dataSB['fileName'] = docs.documentXmlName+str(".zip")
                        dataSB['contentFile'] = zipFileEncoded
                        dataSB['sol'] = data["sol"]
                        docs.fillSendBill(dataSB)
                        self.sunatAPI.setEndPointType("GUIDE") 
                        response = self.sunatAPI.doResquest()                    
                        return response
                else:
                    return "ERROR_DOCUMENT_NOT_ZIPPED"
            else:
                return "ERROR_DOCUMENT_NOT_VERIFIED"
    
    def initDianAPI(self, mode, call):
        self.fileXmlName = self.fileXmlName
        self.sunatAPI = SunatApi(mode, call, self.xmlPath, self.fileXmlName)
        return self.sunatAPI
    
    def setXMLPath(self,xmlPath):
        self.xmlPath = xmlPath

    def validateLicence(self,data):
        response = {}
        has_licence = False
        for key in self.keys:
            if(str(key).strip("\n")==data['licencia']):
                has_licence = True
        if(has_licence==True):
            return True
        else:
            response["status"] = "FAIL"
            response["code"] = "LCC"
            response["body"] = "La licencia del servicio es invalida"
            return response
           