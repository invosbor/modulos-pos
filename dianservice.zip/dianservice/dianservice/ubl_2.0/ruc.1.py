import requests
from bs4 import BeautifulSoup
from PIL import Image
import pytesseract
import os, re

class Ruc:
    endPoint = 'http://e-consultaruc.sunat.gob.pe/cl-ti-itmrconsruc/'
    maxTries = 3
    maxTried = 1
    xmlPath = ''
    def consultNIT(self,ruc):
        raiz = self.endPoint
        
        sesion = requests.session()
        sesion.get(raiz + 'jcrS00Alias')
        pantalla_principal = sesion.get(raiz + 'frameCriterioBusqueda.jsp')

        # Suprimir warning: usar el parser incluido
        soup = BeautifulSoup(pantalla_principal.content, 'html.parser')
        
        ruta_captcha = raiz + soup.find('img').attrs['src']
        imagen = sesion.get(ruta_captcha)

        with os.fdopen(os.open(self.xmlPath+'/imagen.jpg', os.O_WRONLY | os.O_CREAT, 777), 'wb') as captcha:
             captcha.write(imagen.content)
         
        # tessdata
        captcha = pytesseract.image_to_string(Image.open(self.xmlPath+'/imagen.jpg'))

        formdata = {
                'accion': 'consPorRuc',
                'razSoc': '',
                'nroRuc': ruc,
                'nrodoc': '',
                'contexto': 'ti - it',
                'search1': ruc,
                'codigo': captcha,
                'tQuery': 'on',
                'tipdoc': '1',
                'search2': '',
                'coddpto': '',
                'codprov': '',
                'coddist': '',
                'search3': '',
            }

        resultado = sesion.post(raiz + 'jcrS00Alias', data=formdata)
        resultado = BeautifulSoup(resultado.content, 'html.parser')
        response = {}
        try:

            resultado = [td.text.strip() for td in
                        resultado.find('table', attrs={'cellpadding': 2}).find_all('td')]
            itmp = 0
            for posicion, celda in enumerate(resultado):
                #print(str(itmp)+"--"+str(celda))

                if(posicion==1):
                   fullName = celda.strip()
                   fullNameParts = fullName.split("-")
                   companyName = str(fullNameParts[1]).strip()
                   response['name'] = companyName

                if(posicion==3):
                   tipoContribuyente = celda.strip()
                   response['tipo_contribuyente'] = tipoContribuyente

                if(posicion==5):
                   nombreComercial = celda.strip()
                   response['nombre_comercial'] = nombreComercial

                if(posicion==18):
                   sistemaEmisionComprobante = celda.strip()
                   response['sistema_emision_comprobante'] = sistemaEmisionComprobante

                if(posicion==22):
                   sistemaEmisionComprobante = celda.strip()
                   response['sistema_contabilidad'] = sistemaEmisionComprobante

                if(posicion==16):
                   fullAddress = celda.strip()
                   fullAddressParts = fullAddress.split("-")
                   address = str(fullAddressParts[0]).strip()
                   city = str(fullAddressParts[2]).strip()
                   department = str(fullAddressParts[1]).strip()
                   response['address'] = address
                   response['city'] = city
                   response['department'] = department
                
                if(posicion==24):
                   activities = list()
                   actividadEconomica = celda.strip()
                   actividadEconomica = re.sub(r'\W+ -', '', actividadEconomica)
                   actividadEconomica = actividadEconomica.split("\n")
                   for activity in actividadEconomica:
                       activity = activity.replace("-","")
                       if(activity.strip()!=""):
                          activities.append(activity.strip())                     
                   #print(activities)
                   response['actividad_economica'] = activities

                itmp= (itmp+1)
                
        except Exception as e:
            if(self.maxTried<self.maxTries):               
               self.consultNIT(ruc)
               self.maxTried = self.maxTried+1
            if(self.maxTried==self.maxTries):
               #response = "Servicio no disponible temporalmente. \n Debug:"+str(e)
               response = "Servicio no disponible temporalmente."
               return response

        return response
    
    def setXMLPath(self, xmlPath):
        self.xmlPath = xmlPath
               