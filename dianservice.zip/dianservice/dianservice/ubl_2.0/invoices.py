from lxml import etree
import json

class Invoices:

    def fillDocument(self, XMLpath, fileName,  data):
        
        tree = etree.parse(XMLpath+"/XMLdocuments/1_unfilled/UNFILLED-invoice.XML")
        XMLFileContents = etree.tostring(tree.getroot(), pretty_print = True, xml_declaration = True, encoding='UTF-8', standalone="yes")

        #fill xml with data
        data  = json.dumps(data , indent=4)
        data = json.loads(data)
        InvoiceNode = tree.getroot()
        documentID = str(data["serie"])+"-"+str(data["numero"])

        #EXTENSIONS -> AdditionalMonetaryTotal
        for AdditionalMonetaryTotal in InvoiceNode.iter(self.getInvoiceNameSpace("sac")+"AdditionalMonetaryTotal"):
            PayableAmount = AdditionalMonetaryTotal.find(self.getInvoiceNameSpace("cbc")+"PayableAmount")
            PayableAmount.text = str(round(float(data["totalVentaGravada"]),2))
            PayableAmount.set("currencyID",data["tipoMoneda"])

        #EXTENSIONS -> AdditionalMoneAdditionalPropertytaryTotal
        for AdditionalProperty in InvoiceNode.iter(self.getInvoiceNameSpace("sac")+"AdditionalProperty"):
            Value = AdditionalProperty.find(self.getInvoiceNameSpace("cbc")+"Value")
            Value.text = self.precioALiteral((data["totalVenta"])) # totalVenta in spanish letters
        
        #DOCUMENT ID
        ID = InvoiceNode.find(self.getInvoiceNameSpace("cbc")+"ID")
        ID.text = documentID

        #ISSUE DATE & TIME
        IssueDate = InvoiceNode.find(self.getInvoiceNameSpace("cbc")+"IssueDate")
        IssueDate.text = data["fechaEmision"]

        IssueTime = InvoiceNode.find(self.getInvoiceNameSpace("cbc")+"IssueTime")
        IssueTime.text = data["horaEmision"]

        #DUE DATE
        for PaymentMeans in InvoiceNode.iter(self.getInvoiceNameSpace("cac")+"PaymentMeans"):
            PaymentDueDate = PaymentMeans.find(self.getInvoiceNameSpace("cbc")+"PaymentDueDate")
            PaymentDueDate.text = data["fechaVencimiento"]

        #DocumentCurrencyCode
        DocumentCurrencyCode = InvoiceNode.find(self.getInvoiceNameSpace("cbc")+"DocumentCurrencyCode")
        DocumentCurrencyCode.text = data["tipoMoneda"]

        #SIGNATURE
        for Signature in InvoiceNode.iter(self.getInvoiceNameSpace("cac")+"Signature"):
            ID = Signature.find(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = "S"+documentID

            SignatoryParty = Signature.find(self.getInvoiceNameSpace("cac")+"SignatoryParty")
            PartyIdentification = SignatoryParty.find(self.getInvoiceNameSpace("cac")+"PartyIdentification")
            ID = PartyIdentification.find(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = data["emisor"]["nro"] 

            PartyName = SignatoryParty.find(self.getInvoiceNameSpace("cac")+"PartyName")
            Name = PartyName.find(self.getInvoiceNameSpace("cbc")+"Name")
            Name.text = etree.CDATA(data["emisor"]["nombre"])

            DigitalSignatureAttachment = Signature.find(self.getInvoiceNameSpace("cac")+"DigitalSignatureAttachment")
            ExternalReference = DigitalSignatureAttachment.find(self.getInvoiceNameSpace("cac")+"ExternalReference")
            URI = ExternalReference.find(self.getInvoiceNameSpace("cbc")+"URI")
            URI.text = "#S"+documentID
        
        #AccountingSupplierParty -> PartyName
        for AccountingSupplierParty in InvoiceNode.findall(self.getInvoiceNameSpace("cac")+"AccountingSupplierParty"):

            CustomerAssignedAccountID = AccountingSupplierParty.find(self.getInvoiceNameSpace("cbc")+"CustomerAssignedAccountID")
            CustomerAssignedAccountID.text = data["emisor"]["nro"]

            AdditionalAccountID = AccountingSupplierParty.find(self.getInvoiceNameSpace("cbc")+"AdditionalAccountID")
            AdditionalAccountID.text = str(data["emisor"]["tipo"])
            
            for Party in AccountingSupplierParty.iter(self.getInvoiceNameSpace("cac")+"Party"):
                for PartyName in Party.iter(self.getInvoiceNameSpace("cac")+"PartyName"):
                    Name = PartyName.find(self.getInvoiceNameSpace("cbc")+"Name")
                    Name.text = etree.CDATA(data["emisor"]["nombre"])
                
                for PostalAddress in Party.iter(self.getInvoiceNameSpace("cac")+"PostalAddress"):
                    ID = PostalAddress.find(self.getInvoiceNameSpace("cbc")+"ID")
                    ID.text = data["emisor"]["codigoPostal"]

                    StreetName = PostalAddress.find(self.getInvoiceNameSpace("cbc")+"StreetName")
                    StreetName.text = etree.CDATA( data["emisor"]["direccion"])

                    CitySubdivisionName = PostalAddress.find(self.getInvoiceNameSpace("cbc")+"CitySubdivisionName")
                    CitySubdivisionName.text = etree.CDATA("") #urbanizacion

                    CityName = PostalAddress.find(self.getInvoiceNameSpace("cbc")+"CityName")
                    CityName.text = etree.CDATA(data["emisor"]["ciudad"])

                    CountrySubentity = PostalAddress.find(self.getInvoiceNameSpace("cbc")+"CountrySubentity")
                    CountrySubentity.text = etree.CDATA(data["emisor"]["departamento"])

                    District = PostalAddress.find(self.getInvoiceNameSpace("cbc")+"District")
                    District.text = etree.CDATA(data["emisor"]["ciudad"])

                    Country = PostalAddress.find(self.getInvoiceNameSpace("cac")+"Country")
                    IdentificationCode = Country.find(self.getInvoiceNameSpace("cbc")+"IdentificationCode")
                    IdentificationCode.text = etree.CDATA(data["emisor"]["codigoPais"])
                
                for PartyLegalEntity  in Party.iter(self.getInvoiceNameSpace("cac")+"PartyLegalEntity"):
                    RegistrationName = PartyLegalEntity.find(self.getInvoiceNameSpace("cbc")+"RegistrationName")
                    RegistrationName.text = etree.CDATA(data["emisor"]["nombre"])                    

        
        #AccountingCustomerParty -> PartyName
        for AccountingCustomerParty in InvoiceNode.findall(self.getInvoiceNameSpace("cac")+"AccountingCustomerParty"):
            CustomerAssignedAccountID = AccountingCustomerParty.find(self.getInvoiceNameSpace("cbc")+"CustomerAssignedAccountID")
            CustomerAssignedAccountID.text = data["receptor"]["nro"]

            AdditionalAccountID = AccountingCustomerParty.find(self.getInvoiceNameSpace("cbc")+"AdditionalAccountID")
            AdditionalAccountID.text = str(data["receptor"]["tipo"])

            Party =  AccountingCustomerParty.find(self.getInvoiceNameSpace("cac")+"Party")

            PhysicalLocation = Party.find(self.getInvoiceNameSpace("cac")+"PhysicalLocation")
            Description = PhysicalLocation.find(self.getInvoiceNameSpace("cbc")+"Description")
            Description.text = etree.CDATA(data["receptor"]["direccion"])

            PartyLegalEntity = Party.find(self.getInvoiceNameSpace("cac")+"PartyLegalEntity")
            RegistrationName = PartyLegalEntity.find(self.getInvoiceNameSpace("cbc")+"RegistrationName")
            RegistrationName.text = etree.CDATA(data["receptor"]["nombre"])
            

 
        #TAXTOTAL
        for TaxTotal in InvoiceNode.findall(self.getInvoiceNameSpace("cac")+"TaxTotal"):
            TaxAmount = TaxTotal.find(self.getInvoiceNameSpace("cbc")+"TaxAmount")
            TaxAmount.text =  str(round(float(data["sumatoriaIgv"]),2))
            TaxAmount.set("currencyID",data["tipoMoneda"])

            TaxSubtotal = TaxTotal.find(self.getInvoiceNameSpace("cac")+"TaxSubtotal")
            TaxAmount = TaxSubtotal.find(self.getInvoiceNameSpace("cbc")+"TaxAmount")
            TaxAmount.text = str(round(float(data["sumatoriaIgv"]),2))
            TaxAmount.set("currencyID",data["tipoMoneda"])
            
            TaxCategory = TaxSubtotal.find(self.getInvoiceNameSpace("cac")+"TaxCategory")
            TaxScheme = TaxCategory.find(self.getInvoiceNameSpace("cac")+"TaxScheme")
            ID = TaxScheme.find(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = "1000" 
            Name = TaxScheme.find(self.getInvoiceNameSpace("cbc")+"Name")
            Name.text = "IGV"
            TaxTypeCode = TaxScheme.find(self.getInvoiceNameSpace("cbc")+"TaxTypeCode")
            TaxTypeCode.text = "VAT"

        #LegalMonetaryTotal
        for LegalMonetaryTotal in InvoiceNode.findall(self.getInvoiceNameSpace("cac")+"LegalMonetaryTotal"):
            PayableAmount =  LegalMonetaryTotal.find(self.getInvoiceNameSpace("cbc")+"PayableAmount")
            PayableAmount.text = str(round(float(data["totalVenta"]),2))
            PayableAmount.set("currencyID",data["tipoMoneda"])

        #INVOICE LINES
        index = 0
        #item = data["items"][index]
        items = data["items"]
        for item in items:         
            InvoiceLine = etree.Element(self.getInvoiceNameSpace("cac")+"InvoiceLine")
            ID = etree.Element(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = str(index+1)
            InvoiceLine.append(ID)

            InvoicedQuantity = etree.Element(self.getInvoiceNameSpace("cbc")+"InvoicedQuantity")
            InvoicedQuantity.text = item["cantidad"]
            InvoicedQuantity.set("unitCode",item["unidadMedidaCantidad"])
            InvoiceLine.append(InvoicedQuantity)

            LineExtensionAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"LineExtensionAmount")
            LineExtensionAmount.text = str(item["valorVenta"])
            LineExtensionAmount.set("currencyID",data["tipoMoneda"])
            InvoiceLine.append(LineExtensionAmount)
            
            PricingReference = etree.Element(self.getInvoiceNameSpace("cac")+"PricingReference")
            AlternativeConditionPrice = etree.Element(self.getInvoiceNameSpace("cac")+"AlternativeConditionPrice")
            PriceAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"PriceAmount")
            PriceAmount.text =str(round(float(item["precioVentaUnitario"]),2))
            PriceAmount.set("currencyID",data["tipoMoneda"])
            AlternativeConditionPrice.append(PriceAmount)        
            PriceTypeCode = etree.Element(self.getInvoiceNameSpace("cbc")+"PriceTypeCode")
            PriceTypeCode.text = item["tipoPrecioVentaUnitario"]
            AlternativeConditionPrice.append(PriceTypeCode)   
            PricingReference.append(AlternativeConditionPrice)
            InvoiceLine.append(PricingReference)

            TaxTotal = etree.Element(self.getInvoiceNameSpace("cac")+"TaxTotal")
            TaxAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxAmount")
            TaxAmount.text = str(round(float(item["montoAfectacionIgv"]),2))
            TaxAmount.set("currencyID",data["tipoMoneda"])
            TaxTotal.append(TaxAmount)
            TaxSubtotal = etree.Element(self.getInvoiceNameSpace("cac")+"TaxSubtotal")
            TaxAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxAmount")
            TaxAmount.text = str(round(float(item["montoAfectacionIgv"]),2))
            TaxAmount.set("currencyID",data["tipoMoneda"])
            TaxSubtotal.append(TaxAmount)               
            TaxCategory = etree.Element(self.getInvoiceNameSpace("cac")+"TaxCategory")
            TaxExemptionReasonCode = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxExemptionReasonCode")
            TaxExemptionReasonCode.text = item["tipoAfectacionIgv"]
            TaxCategory.append(TaxExemptionReasonCode)
            TaxScheme = etree.Element(self.getInvoiceNameSpace("cac")+"TaxScheme")
            ID = etree.Element(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = "1000"
            TaxScheme.append(ID)
            Name = etree.Element(self.getInvoiceNameSpace("cbc")+"Name")
            Name.text = "IGV"
            TaxScheme.append(Name)
            TaxTypeCode = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxTypeCode")
            TaxTypeCode.text = "VAT"
            TaxScheme.append(TaxTypeCode)
            TaxCategory.append(TaxScheme)
            TaxSubtotal.append(TaxCategory)    
            TaxTotal.append(TaxSubtotal)
            InvoiceLine.append(TaxTotal)

            Item = etree.Element(self.getInvoiceNameSpace("cac")+"Item")
            Description = etree.Element(self.getInvoiceNameSpace("cbc")+"Description")
            Description.text = etree.CDATA(item["descripcion"])
            Item.append(Description)
            SellersItemIdentification =  etree.Element(self.getInvoiceNameSpace("cac")+"SellersItemIdentification")
            ID = etree.Element(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = "101"
            SellersItemIdentification.append(ID)
            Item.append(SellersItemIdentification)
            
            InvoiceLine.append(Item)

            Price = etree.Element(self.getInvoiceNameSpace("cac")+"Price")
            PriceAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"PriceAmount")
            PriceAmount.text = str(item["valorVenta"])
            PriceAmount.set("currencyID",data["tipoMoneda"])
            Price.append(PriceAmount)
            InvoiceLine.append(Price)

            InvoiceNode.append(InvoiceLine)
            index = index+1

        tree.write(XMLpath+"/XMLdocuments/2_unsigned/"+fileName+".XML")
        
        return XMLpath+"/XMLdocuments/2_unsigned/"+fileName+".XML"

    def getInvoiceNameSpace(self, namespace):
        if(namespace=="sac"):
           return "{urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1}"
        if(namespace=="cbc"):
           return "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}"
        if(namespace=="ext"):
           return "{urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2}"
        if(namespace=="cac"):
           return "{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}"


    def precioALiteral(self, numero):
        indicador = [("",""),("MIL","MIL"),("MILLON","MILLONES"),("MIL","MIL"),("BILLON","BILLONES")]
        entero = int(numero)
        decimal = int(round((numero - entero)*100))
        #print 'decimal : ',decimal 
        contador = 0
        numero_letras = ""
        while entero >0:
            a = entero % 1000
            if contador == 0:
                en_letras = self.convierte_cifra(a,1).strip()
            else :
                en_letras = self.convierte_cifra(a,0).strip()
            if a==0:
                numero_letras = en_letras+" "+numero_letras
            elif a==1:
                if contador in (1,3):
                    numero_letras = indicador[contador][0]+" "+numero_letras
                else:
                    numero_letras = en_letras+" "+indicador[contador][0]+" "+numero_letras
            else:
                numero_letras = en_letras+" "+indicador[contador][1]+" "+numero_letras
            numero_letras = numero_letras.strip()
            contador = contador + 1
            entero = int(entero / 1000)
        numero_letras = numero_letras+" Y " + str(decimal) +"/100 SOLES"
        return numero_letras
 
    def convierte_cifra(self, numero,sw):
            lista_centana = ["",("CIEN","CIENTO"),"DOSCIENTOS","TRESCIENTOS","CUATROCIENTOS","QUINIENTOS","SEISCIENTOS","SETECIENTOS","OCHOCIENTOS","NOVECIENTOS"]
            lista_decena = ["",("DIEZ","ONCE","DOCE","TRECE","CATORCE","QUINCE","DIECISEIS","DIECISIETE","DIECIOCHO","DIECINUEVE"),
                            ("VEINTE","VEINTI"),("TREINTA","TREINTA Y "),("CUARENTA" , "CUARENTA Y "),
                            ("CINCUENTA" , "CINCUENTA Y "),("SESENTA" , "SESENTA Y "),
                            ("SETENTA" , "SETENTA Y "),("OCHENTA" , "OCHENTA Y "),
                            ("NOVENTA" , "NOVENTA Y ")
                        ]
            lista_unidad = ["",("UN" , "UNO"),"DOS","TRES","CUATRO","CINCO","SEIS","SIETE","OCHO","NUEVE"]
            centena = int (numero / 100)
            decena = int((numero -(centena * 100))/10)
            unidad = int(numero - (centena * 100 + decena * 10))
            #print "centena: ",centena, "decena: ",decena,'unidad: ',unidad
        
            texto_centena = ""
            texto_decena = ""
            texto_unidad = ""
        
            #Validad las centenas
            texto_centena = lista_centana[centena]
            if centena == 1:
                if (decena + unidad)!=0:
                    texto_centena = texto_centena[1]
                else :
                    texto_centena = texto_centena[0]
        
            #Valida las decenas
            texto_decena = lista_decena[decena]
            if decena == 1 :
                texto_decena = texto_decena[unidad]
            elif decena > 1 :
                if unidad != 0 :
                    texto_decena = texto_decena[1]
                else:
                    texto_decena = texto_decena[0]
            #Validar las unidades
            #print "texto_unidad: ",texto_unidad
            if decena != 1:
                texto_unidad = lista_unidad[unidad]
                if unidad == 1:
                    texto_unidad = texto_unidad[sw]
        
            return "%s %s %s" %(texto_centena,texto_decena,texto_unidad)