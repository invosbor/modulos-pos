from lxml import etree
import json
from xml.dom import minidom
import hashlib

class Debitnote:

    def fillDocument(self, XMLpath, fileName,  data):
        
        tree = etree.parse(XMLpath+"/XMLdocuments/1_unfilled/UNFILLED-debit-note.XML")
        XMLFileContents = etree.tostring(tree.getroot(), pretty_print = True, xml_declaration = True, encoding='UTF-8', standalone="yes")

        #fill xml with data
        data  = json.dumps(data , indent=4)
        data = json.loads(data)
        DebitNoteNode = tree.getroot()
        documentID = str("NDB")+str(data['numero'])

        for InvoiceSource in DebitNoteNode.iter(self.getInvoiceNameSpace("sts")+"InvoiceSource"):
            IdentificationCode = InvoiceSource.find(self.getInvoiceNameSpace("cbc")+"IdentificationCode")
            IdentificationCode.text = data["dian"]["autorizacion"]["codigo_pais"]
        
        for InvoiceControl in DebitNoteNode.iter(self.getInvoiceNameSpace("sts")+"InvoiceControl"):
            InvoiceAuthorization = InvoiceControl.find(self.getInvoiceNameSpace("sts")+"InvoiceAuthorization")
            InvoiceAuthorization.text = data["dian"]["autorizacion"]["codigo"]
            
        
        for AuthorizationPeriod in DebitNoteNode.iter(self.getInvoiceNameSpace("sts")+"AuthorizationPeriod"):
            StartDate = AuthorizationPeriod.find(self.getInvoiceNameSpace("cbc")+"StartDate")
            StartDate.text = data["dian"]["autorizacion"]["fecha_inicio"]
            EndDate = AuthorizationPeriod.find(self.getInvoiceNameSpace("cbc")+"EndDate")
            EndDate.text = data["dian"]["autorizacion"]["fecha_fin"]

        for AuthorizedInvoices in DebitNoteNode.iter(self.getInvoiceNameSpace("sts")+"AuthorizedInvoices"):
            Prefix = AuthorizedInvoices.find(self.getInvoiceNameSpace("sts")+"Prefix")
            Prefix.text = data["dian"]["autorizacion"]["prefijo"]
            From = AuthorizedInvoices.find(self.getInvoiceNameSpace("sts")+"From")
            From.text = data["dian"]["autorizacion"]["desde"]
            To = AuthorizedInvoices.find(self.getInvoiceNameSpace("sts")+"To")
            To.text = data["dian"]["autorizacion"]["hasta"]
        
        for SoftwareProvider in DebitNoteNode.iter(self.getInvoiceNameSpace("sts")+"SoftwareProvider"):
            ProviderID = SoftwareProvider.find(self.getInvoiceNameSpace("sts")+"ProviderID")
            ProviderID.text = data["dian"]["nit"]
            SoftwareID = SoftwareProvider.find(self.getInvoiceNameSpace("sts")+"SoftwareID")
            SoftwareID.text = data["dian"]["identificador_software"]

        for DianExtensions in DebitNoteNode.iter(self.getInvoiceNameSpace("sts")+"DianExtensions"):
            SoftwareSecurityCode = DianExtensions.find(self.getInvoiceNameSpace("sts")+"SoftwareSecurityCode")
            SoftwareSecurityCode.text =  str(hashlib.sha384(str(str(data["dian"]["identificador_software"]) + str(data["dian"]["pin_software"]) + documentID).encode('utf-8')).hexdigest())
       
        #DOCUMENT ID
        ID = DebitNoteNode.find(self.getInvoiceNameSpace("cbc")+"ID")
        ID.text = documentID

        #ISSUE DATE & TIME
        IssueDate = DebitNoteNode.find(self.getInvoiceNameSpace("cbc")+"IssueDate")
        IssueDate.text = data["fechaEmision"]

        IssueTime = DebitNoteNode.find(self.getInvoiceNameSpace("cbc")+"IssueTime")
        IssueTime.text = data["horaEmision"]

        Note = DebitNoteNode.find(self.getInvoiceNameSpace("cbc")+"Note")
        Note.text = str("Nota de dédito: ")+str(data["notaDescripcion"])+str(" ")+str(self.priceToLetter((data["totalVentaGravada"]))) # totalVenta in spanish letters
               
        #DocumentCurrencyCode
        DocumentCurrencyCode = DebitNoteNode.find(self.getInvoiceNameSpace("cbc")+"DocumentCurrencyCode")
        DocumentCurrencyCode.text = data["tipoMoneda"]
        DocumentCurrencyCode.set("listID","ISO 4217 Alpha")
        DocumentCurrencyCode.set("listName","Currency")
        DocumentCurrencyCode.set("listAgencyName","United Nations Economic Commission for Europe")
        LineCountNumeric = DebitNoteNode.find(self.getInvoiceNameSpace("cbc")+"LineCountNumeric")  
        LineCountNumeric.text = str(len(data["items"]))

        #DiscrepancyResponse
        for DiscrepancyResponse in DebitNoteNode.findall(self.getInvoiceNameSpace("cac")+"DiscrepancyResponse"):
            ReferenceID = DiscrepancyResponse.find(self.getInvoiceNameSpace("cbc")+"ReferenceID")
            ReferenceID.text = data["documentoOrigen"]
            ResponseCode = DiscrepancyResponse.find(self.getInvoiceNameSpace("cbc")+"ResponseCode")
            ResponseCode.text = data["notaDiscrepanciaCode"]
            Description = DiscrepancyResponse.find(self.getInvoiceNameSpace("cbc")+"Description")
            Description.text = etree.CDATA(data["notaDescripcion"])

       #BillingReference
        for BillingReference in DebitNoteNode.findall(self.getInvoiceNameSpace("cac")+"BillingReference"):
            for InvoiceDocumentReference in BillingReference.findall(self.getInvoiceNameSpace("cac")+"InvoiceDocumentReference"):
                ID = InvoiceDocumentReference.find(self.getInvoiceNameSpace("cbc")+"ID")
                ID.text = documentID
                UUID = InvoiceDocumentReference.find(self.getInvoiceNameSpace("cbc")+"UUID")
                UUID.text = data["CUFE"]
                IssueDate = InvoiceDocumentReference.find(self.getInvoiceNameSpace("cbc")+"IssueDate")
                IssueDate.text = data["fechaEmision"]

        for AccountingSupplierParty in DebitNoteNode.findall(self.getInvoiceNameSpace("fe")+"AccountingSupplierParty"):
            AdditionalAccountID = AccountingSupplierParty.find(self.getInvoiceNameSpace("cbc")+"AdditionalAccountID")
            AdditionalAccountID.text = str(data["emisor"]["regimen"])

            for Party in AccountingSupplierParty.iter(self.getInvoiceNameSpace("fe")+"Party"):
                
                for PartyIdentification in Party.iter(self.getInvoiceNameSpace("cac")+"PartyIdentification"):
                    ID = PartyIdentification.find(self.getInvoiceNameSpace("cbc")+"ID")
                    ID.text = data["emisor"]["nro"] 
                    ID.set("schemeAgencyID","195")
                    ID.set("schemeAgencyName","CO, DIAN (Direccion de Impuestos y Aduanas Nacionales)")
                    ID.set("schemeID",data["emisor"]["tipo_documento"])

                for PartyName in Party.iter(self.getInvoiceNameSpace("cac")+"PartyName"):
                    Name = PartyName.find(self.getInvoiceNameSpace("cbc")+"Name")
                    Name.text = etree.CDATA(data["emisor"]["nombre"])

                for PhysicalLocation in Party.iter(self.getInvoiceNameSpace("fe")+"PhysicalLocation"):
                    for Address in PhysicalLocation.iter(self.getInvoiceNameSpace("fe")+"Address"):                        
                        Department = Address.find(self.getInvoiceNameSpace("cbc")+"Department")
                        Department.text = etree.CDATA(data["emisor"]["departamento"])

                        CitySubdivisionName = Address.find(self.getInvoiceNameSpace("cbc")+"CitySubdivisionName")
                        CitySubdivisionName.text = etree.CDATA(str(data["emisor"]["ciudad_sector"]))

                        CityName = Address.find(self.getInvoiceNameSpace("cbc")+"CityName")
                        CityName.text = data["emisor"]["ciudad"]

                        for AddressLine in Address.iter(self.getInvoiceNameSpace("cac")+"AddressLine"):
                            Line = AddressLine.find(self.getInvoiceNameSpace("cbc")+"Line")
                            Line.text = etree.CDATA(data["emisor"]["direccion"])

                        for Country in Address.iter(self.getInvoiceNameSpace("cac")+"Country"):
                            IdentificationCode = Country.find(self.getInvoiceNameSpace("cbc")+"IdentificationCode")
                            IdentificationCode.text = data["emisor"]["codigoPais"]

                for PartyTaxScheme in Party.iter(self.getInvoiceNameSpace("fe")+"PartyTaxScheme"):
                    TaxLevelCode = PartyTaxScheme.find(self.getInvoiceNameSpace("cbc")+"TaxLevelCode")
                    TaxLevelCode.text = data["emisor"]["regimen"]

                for PartyLegalEntity in Party.iter(self.getInvoiceNameSpace("fe")+"PartyLegalEntity"):
                    RegistrationName = PartyLegalEntity.find(self.getInvoiceNameSpace("cbc")+"RegistrationName")
                    RegistrationName.text = etree.CDATA(data["emisor"]["nombre"])
            
        
        for AccountingCustomerParty in DebitNoteNode.findall(self.getInvoiceNameSpace("fe")+"AccountingCustomerParty"):
            AdditionalAccountID = AccountingCustomerParty.find(self.getInvoiceNameSpace("cbc")+"AdditionalAccountID")
            AdditionalAccountID.text = str(data["receptor"]["regimen"])

            for Party in AccountingCustomerParty.iter(self.getInvoiceNameSpace("fe")+"Party"):
                
                for PartyIdentification in Party.iter(self.getInvoiceNameSpace("cac")+"PartyIdentification"):
                    ID = PartyIdentification.find(self.getInvoiceNameSpace("cbc")+"ID")
                    ID.text = data["receptor"]["nro"] 
                    ID.set("schemeAgencyID","195")
                    ID.set("schemeAgencyName","CO, DIAN (Direccion de Impuestos y Aduanas Nacionales)")
                    ID.set("schemeID",data["emisor"]["tipo_documento"])

                for PartyName in Party.iter(self.getInvoiceNameSpace("cac")+"PartyName"):
                    Name = PartyName.find(self.getInvoiceNameSpace("cbc")+"Name")
                    Name.text = etree.CDATA(data["receptor"]["nombre"])

                for PhysicalLocation in Party.iter(self.getInvoiceNameSpace("fe")+"PhysicalLocation"):
                    for Address in PhysicalLocation.iter(self.getInvoiceNameSpace("fe")+"Address"):                        
                        Department = Address.find(self.getInvoiceNameSpace("cbc")+"Department")
                        Department.text = etree.CDATA(data["receptor"]["departamento"])

                        CitySubdivisionName = Address.find(self.getInvoiceNameSpace("cbc")+"CitySubdivisionName")
                        CitySubdivisionName.text = etree.CDATA(str(data["receptor"]["ciudad_sector"]))

                        CityName = Address.find(self.getInvoiceNameSpace("cbc")+"CityName")
                        CityName.text = data["receptor"]["ciudad"]

                        for AddressLine in Address.iter(self.getInvoiceNameSpace("cac")+"AddressLine"):
                            Line = AddressLine.find(self.getInvoiceNameSpace("cbc")+"Line")
                            Line.text = etree.CDATA(data["receptor"]["direccion"])

                        for Country in Address.iter(self.getInvoiceNameSpace("cac")+"Country"):
                            IdentificationCode = Country.find(self.getInvoiceNameSpace("cbc")+"IdentificationCode")
                            IdentificationCode.text = data["receptor"]["codigoPais"]

                for PartyTaxScheme in Party.iter(self.getInvoiceNameSpace("fe")+"PartyTaxScheme"):
                    TaxLevelCode = PartyTaxScheme.find(self.getInvoiceNameSpace("cbc")+"TaxLevelCode")
                    TaxLevelCode.text = data["receptor"]["regimen"]

                for PartyLegalEntity in Party.iter(self.getInvoiceNameSpace("fe")+"PartyLegalEntity"):
                    RegistrationName = PartyLegalEntity.find(self.getInvoiceNameSpace("cbc")+"RegistrationName")
                    RegistrationName.text = etree.CDATA(data["receptor"]["nombre"])
        
        #Global tax information
        tributos = data['tributos']
        for tributo_name in tributos:
            tributo = tributos[str(tributo_name)]
            for tributo_item_percent_differenced in tributo:
                TaxTotal = etree.Element(self.getInvoiceNameSpace("fe")+"TaxTotal")
                TaxAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxAmount")
                TaxAmount.text =  str(round(float(tributo_item_percent_differenced['sumatoria']),2))
                TaxAmount.set("currencyID",data["tipoMoneda"])
                TaxTotal.append(TaxAmount)

                TaxEvidenceIndicator = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxEvidenceIndicator")
                TaxEvidenceIndicator.text = str("false")
                TaxTotal.append(TaxEvidenceIndicator)
        
                TaxSubtotal = etree.Element(self.getInvoiceNameSpace("fe")+"TaxSubtotal")
                TaxableAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxableAmount")
                TaxableAmount.text = str(tributo_item_percent_differenced['total_venta'])
                TaxableAmount.set("currencyID",data["tipoMoneda"])
                TaxSubtotal.append(TaxableAmount)

                TaxAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxAmount")
                TaxAmount.text = str(tributo_item_percent_differenced['sumatoria'])
                TaxAmount.set("currencyID",data["tipoMoneda"])
                TaxSubtotal.append(TaxAmount)

                Percent = etree.Element(self.getInvoiceNameSpace("cbc")+"Percent")
                Percent.text = str(tributo_item_percent_differenced['porcentaje'])
                TaxSubtotal.append(Percent) 

                TaxCategory = etree.Element(self.getInvoiceNameSpace("cac")+"TaxCategory")
                TaxScheme = etree.Element(self.getInvoiceNameSpace("cac")+"TaxScheme")
                ID = etree.Element(self.getInvoiceNameSpace("cbc")+"ID")
                ID.text = tributo_item_percent_differenced['codigo']
                TaxScheme.append(ID)
                TaxCategory.append(TaxScheme)

                TaxSubtotal.append(TaxCategory)
                TaxTotal.append(TaxSubtotal)
                DebitNoteNode.append(TaxTotal)
        


        LegalMonetaryTotal = etree.Element(self.getInvoiceNameSpace("fe")+"LegalMonetaryTotal")
        # Valor bruto antes de tributos: Total valor bruto, suma de los valores brutos de las líneas de la factura.
        LineExtensionAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"LineExtensionAmount")
        LineExtensionAmount.text = str(data["subTotalVenta"])
        LineExtensionAmount.set("currencyID",data["tipoMoneda"])
        LegalMonetaryTotal.append(LineExtensionAmount)

        # Total Base Imponible (Valor Bruto+Cargos - Descuentos): Base imponible para el cálculo de los tributos
        TaxExclusiveAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxExclusiveAmount")
        TaxExclusiveAmount.text = str(data["subTotalVenta"])
        TaxExclusiveAmount.set("currencyID",data["tipoMoneda"])
        LegalMonetaryTotal.append(TaxExclusiveAmount)

        # Total de Valor bruto con tributos. Los tributos retenidos son retirados en el cálculo de PayableAmount
        TaxInclusiveAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"TaxInclusiveAmount")
        TaxInclusiveAmount.text = str(data["totalVentaGravada"])
        TaxInclusiveAmount.set("currencyID",data["tipoMoneda"])
        LegalMonetaryTotal.append(TaxInclusiveAmount)

        # Valor Pagable de Factura: Valor total de ítems (incluyendo cargos y descuentos a PayableAmount
        PayableAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"PayableAmount")
        PayableAmount.text = str(data["totalVentaGravada"])
        PayableAmount.set("currencyID",data["tipoMoneda"])
        LegalMonetaryTotal.append(PayableAmount)
        DebitNoteNode.append(LegalMonetaryTotal)

        #INVOICE LINES
        index = 0
        items = data["items"]
        for item in items:  
            DebitNoteLine = etree.Element(self.getInvoiceNameSpace("fe")+"DebitNoteLine")
            ID = etree.Element(self.getInvoiceNameSpace("cbc")+"ID")
            ID.text = str(index+1)
            DebitNoteLine.append(ID)

            DebitedQuantity = etree.Element(self.getInvoiceNameSpace("cbc")+"DebitedQuantity")
            DebitedQuantity.text = item["cantidad"]            
            DebitNoteLine.append(DebitedQuantity)

            LineExtensionAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"LineExtensionAmount")
            LineExtensionAmount.text = str(item["subTotalVenta"])
            LineExtensionAmount.set("currencyID",data["tipoMoneda"])
            DebitNoteLine.append(LineExtensionAmount)

            
            Item = etree.Element(self.getInvoiceNameSpace("fe")+"Item")
            Description = etree.Element(self.getInvoiceNameSpace("cbc")+"Description")
            Description.text = item['descripcion']
            Item.append(Description)

            CommodityClassification =  etree.Element(self.getInvoiceNameSpace("cac")+"CommodityClassification")
            ItemClassificationCode = etree.Element(self.getInvoiceNameSpace("cbc")+"ItemClassificationCode")
            ItemClassificationCode.text = item["clasificacionProductoServicioCodigo"]
            CommodityClassification.append(ItemClassificationCode)
            #Item.append(ItemClassificationCode)

            DebitNoteLine.append(Item)

            Price = etree.Element(self.getInvoiceNameSpace("fe")+"Price")
            PriceAmount = etree.Element(self.getInvoiceNameSpace("cbc")+"PriceAmount")
            PriceAmount.text = str(item['precioUnidad'])
            PriceAmount.set("currencyID",data["tipoMoneda"])
            Price.append(PriceAmount)
            DebitNoteLine.append(Price)

            DebitNoteNode.append(DebitNoteLine) 
            index = index+1

        tree.write(XMLpath+"/XMLdocuments/2_unsigned/"+fileName+".XML", pretty_print = True, xml_declaration = True, encoding='UTF-8', standalone="yes")
        self.prettyXMLSave(XMLpath+"/XMLdocuments/2_unsigned/"+fileName+".XML")
        return XMLpath+"/XMLdocuments/2_unsigned/"+fileName+".XML"

    def getGlobalTaxAmount(self, tributos):
        sumatoria = float(0.0)
        for tributo_name in tributos:
            tributo = tributos[str(tributo_name)]
            for item in tributo:
                sumatoria +=  float(item["sumatoria"])
        return str(sumatoria)

    
    def getGlobalTaxableAmount(self, tributos):
        total_venta = 0.0
        for tributo_percent_differenced in tributos:
            for item in tributo_percent_differenced:
                total_venta +=  float(item["total_venta"])

    def getInvoiceNameSpace(self, namespace):
        if(namespace=="sac"):
           return "{urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1}"
        if(namespace=="cbc"):
           return "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}"
        if(namespace=="ext"):
           return "{urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2}"
        if(namespace=="cac"):
           return "{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}"
        if(namespace=="fe"):
           return "{http://www.dian.gov.co/contratos/facturaelectronica/v1}"
        if(namespace=="sts"):
           return "{http://www.dian.gov.co/contratos/facturaelectronica/v1/Structures}"


    def priceToLetter(self, numero):
        indicador = [("",""),("MIL","MIL"),("MILLON","MILLONES"),("MIL","MIL"),("BILLON","BILLONES")]
        entero = int(numero)
        decimal = int(round((numero - entero)*100))
        #print 'decimal : ',decimal 
        contador = 0
        numero_letras = ""
        while entero >0:
            a = entero % 1000
            if contador == 0:
                en_letras = self.priceToLetterInternal(a,1).strip()
            else :
                en_letras = self.priceToLetterInternal(a,0).strip()
            if a==0:
                numero_letras = en_letras+" "+numero_letras
            elif a==1:
                if contador in (1,3):
                    numero_letras = indicador[contador][0]+" "+numero_letras
                else:
                    numero_letras = en_letras+" "+indicador[contador][0]+" "+numero_letras
            else:
                numero_letras = en_letras+" "+indicador[contador][1]+" "+numero_letras
            numero_letras = numero_letras.strip()
            contador = contador + 1
            entero = int(entero / 1000)
        numero_letras = numero_letras+" Y " + str(decimal) +"/100 PESOS"
        return numero_letras

 
    def priceToLetterInternal(self, numero,sw):
        lista_centana = ["",("CIEN","CIENTO"),"DOSCIENTOS","TRESCIENTOS","CUATROCIENTOS","QUINIENTOS","SEISCIENTOS","SETECIENTOS","OCHOCIENTOS","NOVECIENTOS"]
        lista_decena = ["",("DIEZ","ONCE","DOCE","TRECE","CATORCE","QUINCE","DIECISEIS","DIECISIETE","DIECIOCHO","DIECINUEVE"),
                        ("VEINTE","VEINTI"),("TREINTA","TREINTA Y "),("CUARENTA" , "CUARENTA Y "),
                        ("CINCUENTA" , "CINCUENTA Y "),("SESENTA" , "SESENTA Y "),
                        ("SETENTA" , "SETENTA Y "),("OCHENTA" , "OCHENTA Y "),
                        ("NOVENTA" , "NOVENTA Y ")
                    ]
        lista_unidad = ["",("UN" , "UNO"),"DOS","TRES","CUATRO","CINCO","SEIS","SIETE","OCHO","NUEVE"]
        centena = int (numero / 100)
        decena = int((numero -(centena * 100))/10)
        unidad = int(numero - (centena * 100 + decena * 10))
        #print "centena: ",centena, "decena: ",decena,'unidad: ',unidad
    
        texto_centena = ""
        texto_decena = ""
        texto_unidad = ""
    
        #Validad las centenas
        texto_centena = lista_centana[centena]
        if centena == 1:
            if (decena + unidad)!=0:
                texto_centena = texto_centena[1]
            else :
                texto_centena = texto_centena[0]
    
        #Valida las decenas
        texto_decena = lista_decena[decena]
        if decena == 1 :
            texto_decena = texto_decena[unidad]
        elif decena > 1 :
            if unidad != 0 :
                texto_decena = texto_decena[1]
            else:
                texto_decena = texto_decena[0]
        #Validar las unidades
        #print "texto_unidad: ",texto_unidad
        if decena != 1:
            texto_unidad = lista_unidad[unidad]
            if unidad == 1:
                texto_unidad = texto_unidad[sw]
    
        return "%s %s %s" %(texto_centena,texto_decena,texto_unidad)

    def prettyXMLSave(self, pathFile):
        tree = etree.parse(pathFile)  
        xmlstr = minidom.parseString(etree.tostring(tree.getroot())).toprettyxml(indent="   ")
        with open(pathFile, "w") as f:
            f.write(xmlstr)