import base64
from zipfile import ZipFile
from lxml import etree
import os
from . certificate import XMLSigner
from . certificate import XMLVerifier
from . invoices import Invoices
from . tickets import Tickets
from . creditnote import Creditnote
from . debitnote import Debitnote
from . guide import Guide
import hashlib

class Documents:

    xmlPath = False

    documentXmlName = False
    documentZipName = False

    def fillDocument(self, whichDocument, data):

        fileFilled = False
        if(whichDocument=="invoice"):
           invoice = Invoices()
           fileFilled = invoice.fillDocument(self.xmlPath, self.documentXmlName, data)

        if(whichDocument=="ticket"):
           ticket = Tickets()
           fileFilled = ticket.fillDocument(self.xmlPath, self.documentXmlName, data)
        
        if(whichDocument=="creditNote"):
           creditNote = Creditnote()
           fileFilled = creditNote.fillDocument(self.xmlPath, self.documentXmlName, data)

        if(whichDocument=="debitNote"):
           debitNote = Debitnote()
           fileFilled = debitNote.fillDocument(self.xmlPath, self.documentXmlName, data)

        if(whichDocument=="deliveryGuide"):
           deliveryGuide = Guide()
           fileFilled = deliveryGuide.fillDocument(self.xmlPath, self.documentXmlName, data)

        return fileFilled

    def signDocument(self, key, cert):
        signed_root = XMLSigner().sign(self.xmlPath+"/XMLdocuments/2_unsigned/"+self.documentXmlName+".XML", key_data=key, cert_data=cert)
        signed_doc_str = etree.tostring(signed_root, xml_declaration=True, encoding='ISO-8859-1', pretty_print=True)
        self.saveSignedDocument(self.xmlPath+"/XMLdocuments/3_signed/"+self.documentXmlName+".XML", signed_doc_str)
        return True

    def saveSignedDocument(self, newDocument, XMLcontents):
        f = open(newDocument, "wb")
        f.write(XMLcontents)
        f.close()

    def verifyDocument(self, key):
        verified = XMLVerifier().verify(self.xmlPath+"/XMLdocuments/3_signed/"+self.documentXmlName+".XML", key_data=key)
        return verified

    def zipDocument(self, sourcePath, targetPath, fileName):
        try:           
            xmlSource = str(self.xmlPath+'/XMLdocuments/3_signed/')+str(self.documentXmlName)+str(".XML")
            zipTarget = str(self.xmlPath+'/XMLdocuments/4_compressed/')+str(self.documentZipName)+".zip"
            ZipFile(zipTarget, 'w').write(xmlSource,self.documentZipName+str(".XML"))
            return True
        except:
            return False

    def Base64EncodeDocument(self):
        fileContents = open(self.xmlPath+'/XMLdocuments/4_compressed/'+str(self.documentZipName)+".zip", "rb").read()
        encoded = base64.b64encode(fileContents)
        return encoded
    
    def getXMLUnsignedDocument(self):
        fileContents = open(self.xmlPath+'/XMLdocuments/2_unsigned/'+str(self.documentXmlName)+".XML", "rb").read()
        encoded = base64.b64encode(fileContents)
        return encoded
        #tree = etree.parse(self.xmlPath+'/XMLdocuments/2_unsigned/'+str(self.documentXmlName)+".XML")
        #XMLFileContents = etree.tostring(tree.getroot(), pretty_print = True, xml_declaration = True, encoding='UTF-8', standalone="yes")        
        #return str(XMLFileContents)

    def getXMLSignedDocument(self):
        fileContents = open(self.xmlPath+'/XMLdocuments/3_signed/'+str(self.documentXmlName)+".XML", "rb").read()
        encoded = base64.b64encode(fileContents)
        return encoded

    def setXMLPath(self,xmlPath):
        self.xmlPath = xmlPath
    
    def resetDocumentProcess(self):
        self.documentXmlName = False
        self.xmlPath = False
    
    def fillSendBill(self, data):
        tree = etree.parse(data['sendBillFile'])
        EnvelopeNode = tree.getroot()
        dian = data['dian']

        for item in EnvelopeNode.iter(self.getSendBillNameSpace("rep")+'NIT'):
            item.text = dian['nit']

        for item in EnvelopeNode.iter(self.getSendBillNameSpace("rep")+'InvoiceNumber'):
            item.text = data['InvoiceNumber']

        for item in EnvelopeNode.iter(self.getSendBillNameSpace("rep")+'IssueDate'):
            item.text = dian['created']      
        
        for item in EnvelopeNode.iter(self.getSendBillNameSpace("rep")+'Document'):
            item.text = data['Document'] 

        #security 

        for Username in EnvelopeNode.iter(self.getSendBillNameSpace("wsse")+"Username"):
            Username.text = dian["identificador_software"]     

        for Password in EnvelopeNode.iter(self.getSendBillNameSpace("wsse")+"Password"):
            
            Password.text = str(hashlib.sha384(str(str(dian["identificador_software"]) + str(dian["pin_software"]) + data['InvoiceNumber']).encode('utf-8')).hexdigest()) 

        for Nonce in EnvelopeNode.iter(self.getSendBillNameSpace("wsse")+"Nonce"):
            Nonce.text = dian["nonce"]   

        for Created in EnvelopeNode.iter(self.getSendBillNameSpace("wsu")+"Created"):
            Created.text = dian["created"] 

        tree.write(data['sendBillFile'])

    def getSendBillNameSpace(self, namespace):
        if(namespace=="wsse"):
           return "{http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd}"

        if(namespace=="wsu"):
           return "{http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd}"

        if(namespace=="rep"):
           return "{http://www.dian.gov.co/servicios/facturaelectronica/ReportarFactura}"

        if(namespace=="soapenv"):
           return "{http://schemas.xmlsoap.org/soap/envelope/}"