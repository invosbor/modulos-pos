sudo rm -r /home/rockscripts/Documents/dianservice/dianservice.egg-info
sudo rm -r /home/rockscripts/Documents/dianservice/dist
sudo rm -r /home/rockscripts/Documents/dianservice/build

sudo python3 setup.py bdist_egg
#sudo python3 setup.py bdist
sudo python3 setup.py bdist_rpm
sudo python3 setup.py install
sudo python3 setup.py bdist_wininst
#sudo python setup.py bdist_egg
#sudo python setup.py bdist
#sudo python setup.py bdist_rpm
#sudo python setup.py install

#twine upload --repository-url https://upload.pypi.org/legacy/  dist/*

#pip3 install -U dianservice

#sudo pip uninstall dianservice
#sudo pip3 uninstall dianservice -y


#Consulta RUC
#sudo apt-get install tesseract-ocr tesseract-ocr-eng phantomjs
#pip install -r pip-requirements.txt
#pip install vatnumber

#sudo mv /home/USUARIO/.local/lib/python3.6/site-packages/xmlsec* /usr/local/lib/python3.6/dist-packages
#sudo mv /home/USUARIO/.local/lib/python3.6/site-packages/bs4* /usr/local/lib/python3.6/dist-packages
#sudo mv /home/ubuntu/.local/lib/python3.6/site-packages/pytesseract* /usr/local/lib/python3.6/dist-packages